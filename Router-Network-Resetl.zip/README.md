# Router Network Reset

> 一键重置路由器网络，实时监控流量、连接、内存等状态，支持自定义IP、端口和Token，界面美观，适合自用和二次开发。

![screenshot](./screenshot.png)

## 功能特性
- 实时流量监控（上传/下载速率折线图，单位自适应）
- 连接数、内存、代理链等状态一目了然
- 一键重置网络连接
- 连接详情支持断开单个连接
- 支持明暗主题切换
- 支持自定义路由器IP、端口、Token
- 响应式美观UI，适合浏览器插件弹窗

## 安装与使用
1. 克隆本项目到本地：
   ```bash
   git clone https://github.com/你的用户名/你的仓库名.git
   ```
2. 打开 Chrome 扩展管理页面，开启"开发者模式"
3. 点击"加载已解压的扩展程序"，选择本项目文件夹
4. 在插件弹窗中设置路由器信息（IP、端口、Token）
5. 即可实时监控和管理你的路由器网络

## 目录结构
```
├── popup.html         # 主界面
├── popup.js           # 前端逻辑
├── echarts.min.js     # 图表库（本地）
├── manifest.json      # 插件配置
├── pwa-192x192.png    # 图标
├── README.md          # 项目说明
└── ...
```

## 界面预览
> ![UI预览](./screenshot.png)

## 参与贡献
欢迎提交PR、Issue，或自定义开发！

## License
MIT 